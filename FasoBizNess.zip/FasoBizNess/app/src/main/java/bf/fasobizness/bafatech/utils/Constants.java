package bf.fasobizness.bafatech.utils;

public class Constants {
    public static final String HOST_URL = "http://fasobizness.com/api/public/";
    // public static final String HOST_URL = "http://192.168.0.105/api/public/";
    // public static final String HOST_URL = "http://10.0.2.2:8000/";
}
