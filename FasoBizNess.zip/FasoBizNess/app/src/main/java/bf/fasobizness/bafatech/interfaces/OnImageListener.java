package bf.fasobizness.bafatech.interfaces;

public interface OnImageListener {
    void onImageClicked(int position);
}
