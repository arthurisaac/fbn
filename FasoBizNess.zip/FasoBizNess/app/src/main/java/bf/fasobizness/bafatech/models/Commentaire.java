package bf.fasobizness.bafatech.models;

class Commentaire {

    private String id_comment;
    private String commentaire;
    private String date;
    private String heure;
    private String id_pers_fk;
    private String id_article_fk;
    private String email;
    private String username;
    private String photo;
    private String tel;
    private String type;

}
