package bf.fasobizness.bafatech.interfaces;

public interface OnItemListener {
    void onItemClicked(int position);
}
