package bf.fasobizness.bafatech.interfaces;

public interface OnMessageListener {
    void onMessageClicked(int position);
}
