package bf.fasobizness.bafatech.interfaces;

public interface OnEntrepriseListener {
    void onEntrepriseClicked(int position);
}
