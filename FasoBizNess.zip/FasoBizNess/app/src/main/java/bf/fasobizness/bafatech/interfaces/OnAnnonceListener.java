package bf.fasobizness.bafatech.interfaces;

public interface OnAnnonceListener {
    void onAnnonceClicked(int position);
}
